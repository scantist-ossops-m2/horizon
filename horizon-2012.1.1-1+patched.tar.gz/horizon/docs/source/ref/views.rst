=============
Horizon Views
=============

Horizon ships with a number of pre-built views which are used within
Horizon and can also be reused in your applications.

Auth
====

.. automodule:: horizon.views.auth
    :members:
