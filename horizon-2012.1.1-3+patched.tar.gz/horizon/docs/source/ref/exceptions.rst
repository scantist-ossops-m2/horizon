==================
Horizon Exceptions
==================

.. automodule:: horizon.exceptions
   :members:
