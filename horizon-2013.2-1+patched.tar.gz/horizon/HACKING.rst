OpenStack Style Commandments
============================

- Step 1: Read http://www.python.org/dev/peps/pep-0008/
- Step 2: Read http://www.python.org/dev/peps/pep-0008/ again
- Step 3: Read https://github.com/openstack-dev/hacking/blob/master/HACKING.rst

The OpenStack Style Commandments live here:

  https://github.com/openstack-dev/hacking/blob/master/HACKING.rst

local-checks
------------

None so far

