from create_instance import LaunchInstance

assert LaunchInstance
